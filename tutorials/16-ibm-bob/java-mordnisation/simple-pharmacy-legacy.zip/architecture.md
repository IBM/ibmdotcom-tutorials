# Simple Pharmacy Dashboard - Architecture and Functional Documentation

## 1. Executive Summary

**Simple Pharmacy Dashboard** (`simple-pharmacy.war`, version 1.0.0) is a small server-rendered web application that supports the day-to-day workflow of a pharmacy: registering patient prescriptions, validating them, converting validated prescriptions into orders, taking (mock) payment, and recording collection of the medication by the patient. It also exposes a searchable medicine catalogue with stock levels.

| Aspect | Detail |
|---|---|
| Domain | Retail pharmacy / prescription fulfilment |
| UI framework | Apache Struts 2.5.30 (action based, `StrutsPrepareAndExecuteFilter`) with the Convention plugin, JSP 2.3 and Struts tags (`<s:*>`), JSTL 1.2 |
| Language / build | Java 8 (`maven.compiler.source/target = 1.8`), Maven WAR packaging |
| Runtime | Open/WebSphere Liberty (features `servlet-3.1`, `jsp-2.3`, `jdbc-4.1`, `mpMetrics-1.1`), HTTP port 9081, HTTPS 9443 |
| Persistence | **None** - in-memory `ConcurrentHashMap` singleton repositories seeded with sample data |
| Security | **None** - no authentication, authorization, CSRF protection or role model |
| Size | 4 actions, 3 entities, 3 repositories, 6 JSP views, 1 `struts.xml` |

Key capabilities:

- Dashboard with counters and pending work lists
- Prescription capture, listing and validation
- Order creation from validated prescriptions with stock check and price calculation
- Payment processing (mock) and order collection
- Medicine catalogue with name search and low-stock highlighting

---

## 2. Functional Overview

### 2.1 Business domain and entities

| Entity | Purpose | Identifier format |
|---|---|---|
| `Medicine` | Catalogue item: name, description, unit price, stock quantity, manufacturer | `MED001`..`MED008` (seeded) |
| `Prescription` | Doctor-issued request for a quantity of one medicine for a patient | `RX001`.. (seeded RX001-RX003, generated `RX` + 3-digit counter starting at 1001) |
| `Order` | Sale record derived from exactly one prescription (patient, medicine, quantity, total, payment) | `ORD` + 4-digit counter starting at 5001 |

### 2.2 Major functional areas

| Area | Struts action class | Capabilities |
|---|---|---|
| Dashboard | `DashboardAction` | Pending prescriptions, pending orders, total prescription and order counts |
| Prescription management | `PrescriptionAction` | List, view, create (form), save, validate |
| Order management | `OrderAction` | List, view, create from prescription, process payment, mark collected |
| Medicine catalogue | `MedicineAction` | List, view, search by name |

### 2.3 Main user workflows / use cases

1. **Review work queue** - open the dashboard (`/` redirects to `dashboard`) and see pending prescriptions and pending orders.
2. **Register a prescription** - fill in patient, doctor, medicine, quantity, dosage and notes; the prescription is stored as `PENDING` with a 30-day expiry.
3. **Validate a prescription** - a pharmacist clicks *Validate* (dashboard or list); status becomes `VALIDATED`.
4. **Create an order** - from a `VALIDATED` prescription; system verifies medicine and stock, computes the total, and creates a `PENDING` order.
5. **Process payment** - on the order view page choose `CASH`, `CREDIT_CARD` or `INSURANCE`, optionally add pharmacist notes; the order becomes `PAID`, the prescription `FULFILLED` and stock is decremented.
6. **Collect order** - from the order list, *Mark Collected* on a `PAID` order sets `COLLECTED`.
7. **Browse / search medicines** - list all medicines or search by (case-insensitive substring of) name; stock below 50 is highlighted as low.

### 2.4 Intended roles

The code defines no roles. Implicitly there is one actor, the **pharmacist / pharmacy staff user**, who performs every step (the page text and the `pharmacistNotes` field imply this). Prescription creation could conceptually be done by clerical staff or an integration with a doctor, but no such distinction exists.

---

## 3. High-Level Functional Flows

### 3.1 End-to-end business process

```mermaid
flowchart LR
    A["Create prescription<br/>status PENDING"] --> B["Validate prescription<br/>status VALIDATED"]
    B --> C["Create order<br/>status PENDING"]
    C --> D["Process payment<br/>order PAID<br/>prescription FULFILLED<br/>stock decremented"]
    D --> E["Mark collected<br/>order COLLECTED"]
```

### 3.2 Prescription lifecycle

```mermaid
stateDiagram-v2
    [*] --> PENDING: prescription-save
    PENDING --> VALIDATED: prescription-validate
    VALIDATED --> FULFILLED: order-processPayment
    PENDING --> EXPIRED: declared only, never set
    FULFILLED --> [*]
```

### 3.3 Order lifecycle

```mermaid
stateDiagram-v2
    [*] --> PENDING: order-createFromPrescription
    PENDING --> PAID: order-processPayment
    PAID --> COLLECTED: order-collect
    PENDING --> CANCELLED: declared only, never set
    COLLECTED --> [*]
```

### 3.4 Create-order sequence

```mermaid
sequenceDiagram
    participant U as User
    participant F as Struts2 Filter
    participant A as OrderAction
    participant PR as PrescriptionRepository
    participant MR as MedicineRepository
    participant OR as OrderRepository
    U->>F: GET order-createFromPrescription?prescriptionId=RX002
    F->>A: createFromPrescription
    A->>PR: findById
    A->>A: status must be VALIDATED
    A->>MR: findById medicineId
    A->>A: stock >= quantity, total = price x quantity
    A->>OR: generateId and addOrder
    A-->>F: SUCCESS
    F-->>U: redirect order-list
```

### 3.5 Navigation map

| From | Link / form | Action | Result |
|---|---|---|---|
| `index.jsp` | server redirect | `dashboard` | `dashboard.jsp` |
| All pages | top nav | `dashboard`, `prescription-list`, `order-list`, `medicine-list` | list pages |
| `prescription-list.jsp` | New Prescription | `prescription-create` | `prescription-create.jsp` |
| `prescription-create.jsp` | POST form | `prescription-save` | redirect `prescription-list` (error: back to create form) |
| `prescription-list.jsp` / `dashboard.jsp` | Validate (when PENDING) | `prescription-validate` | redirect `prescription-list` |
| `prescription-list.jsp` | Create Order (when VALIDATED) | `order-createFromPrescription` | redirect `order-list` (error: redirect `prescription-list`) |
| `order-list.jsp` / `dashboard.jsp` | View / Process Payment | `order-view` | `order-view.jsp` |
| `order-view.jsp` | POST payment form (when PENDING) | `order-processPayment` | redirect `order-list` (error: `order-view.jsp`) |
| `order-list.jsp` | Mark Collected (when PAID) | `order-collect` | redirect `order-list` |
| `medicine-list.jsp` | GET search form | `medicine-search` | `medicine-list.jsp` |
| list pages | View | `prescription-view`, `medicine-view` | **JSP not present** (see 5.8) |

---

## 4. Business Rules and Validations

### 4.1 Validation and constraint rules (all embedded in action classes)

| # | Rule | Location | Failure behaviour |
|---|---|---|---|
| V1 | Selected medicine must exist when saving a prescription | `PrescriptionAction.save` | `addActionError("Medicine not found")` -> `error` (re-render create form) |
| V2 | Prescription id must be supplied and exist to validate | `PrescriptionAction.validatePrescription` | error "Prescription not found" -> redirect list |
| V3 | `prescriptionId` required to create an order | `OrderAction.createFromPrescription` | error "Prescription ID is required" |
| V4 | Prescription must exist | same | "Prescription not found" |
| V5 | Prescription status must equal `VALIDATED` | same | "Prescription must be validated before creating an order" |
| V6 | Medicine referenced by prescription must exist | same | "Medicine not found" |
| V7 | `medicine.stockQuantity >= prescription.quantity` | same | "Insufficient stock. Available: N" |
| V8 | `orderId` required and order must exist for payment | `OrderAction.processPayment` | "Order ID is required" / "Order not found" |
| V9 | Payment method must be non-blank | same | "Payment method is required" |
| V10 | Order must be `PAID` before collection | `OrderAction.collect` | "Order must be paid before collection" |
| V11 | Search with blank query returns all medicines | `MedicineAction.search` | n/a |
| V12 | Client side only: HTML `required`, `min="1"` on quantity; payment method restricted to `CASH`, `CREDIT_CARD`, `INSURANCE` through a select list | JSPs | not enforced server side |

### 4.2 Calculations and data transformation

- **Order total** = `medicine.price x prescription.quantity` (`BigDecimal`).
- **Prescription expiry** = creation date + 30 days (`Calendar.add(DAY_OF_MONTH, 30)`).
- **Order creation** copies patient, medicine, quantity from the prescription (denormalised snapshot) and sets `orderDate = now`, `status = PENDING`.
- **ID generation**: `AtomicInteger` counters (prescriptions start at 1000, orders at 5000, formatted `RX%03d` / `ORD%04d`).
- **Payment side effects**: order -> `PAID`, `paymentMethod` and `pharmacistNotes` stored, prescription -> `FULFILLED`, stock reduced by order quantity via `MedicineRepository.updateStock`.
- **Presentation rules in JSP**: low stock when `stockQuantity < 50`; status CSS class from `status.toLowerCase()`; dates formatted `MM/dd/yyyy`.

### 4.3 Workflow state transitions

| Entity | Declared statuses | Statuses actually set by code |
|---|---|---|
| Prescription | PENDING, VALIDATED, FULFILLED, EXPIRED | PENDING (create), VALIDATED (validate), FULFILLED (payment). `EXPIRED` is never assigned; `expiryDate` is never checked. |
| Order | PENDING, VALIDATED, PAID, COLLECTED, CANCELLED | PENDING (create), PAID (payment), COLLECTED (collect). `VALIDATED` and `CANCELLED` are never assigned. |

### 4.4 Roles and permissions

None implemented. Every action is anonymously reachable (`/*` filter, no `security-constraint` in `web.xml`, no interceptor stack beyond `struts-default`).

### 4.5 Error handling

- Actions use `addActionError` / `addActionMessage` and return `ERROR` / `SUCCESS`; JSPs render `<s:actionerror/>` and `<s:actionmessage/>`.
- `createFromPrescription`, `processPayment`, `collect` and `save` wrap logic in `try/catch (Exception)` and surface `e.getMessage()` to the user (information disclosure risk).
- No `<global-results>` or `<global-exception-mappings>` are configured; unhandled exceptions fall to the container/Struts dev-mode page (`struts.devMode=true`).
- Messages added before a `redirect` result are not preserved (no message-store interceptor), so success/error messages on redirect targets are normally lost.

### 4.6 Known business-logic gaps (observed in code)

- No server-side validation of patient/doctor/dosage fields, or `quantity > 0`.
- Prescription expiry is not enforced when validating or ordering.
- `updateStock` return value is ignored in `processPayment`; stock is only checked at order creation, not at payment, so concurrent orders can oversell.
- Multiple orders can be created from the same prescription while it remains `VALIDATED` (it only becomes `FULFILLED` after payment).
- State-changing operations are performed via HTTP GET links (`prescription-validate`, `order-createFromPrescription`, `order-collect`).
- Payment method value is not validated against the allowed set on the server.

---

## 5. Technical Architecture

### 5.1 Layered view

```mermaid
flowchart TD
    Browser["Browser"] --> Filter["StrutsPrepareAndExecuteFilter<br/>url-pattern /*"]
    Filter --> Config["struts.xml<br/>package pharmacy extends struts-default"]
    Config --> Actions["Action classes<br/>extend ActionSupport"]
    Actions --> Repos["Singleton repositories<br/>ConcurrentHashMap"]
    Repos --> Models["POJO models<br/>Medicine Prescription Order"]
    Actions --> Views["JSP views in WEB-INF/content<br/>Struts tags"]
    Views --> Browser
```

| Layer | Components |
|---|---|
| Presentation | 6 JSPs under `/WEB-INF/content/`, `index.jsp`, Struts tag library, inline CSS |
| Control flow | `web.xml` filter, `struts.xml`, 4 `ActionSupport` classes |
| Business logic | Embedded inside action methods (no service layer) |
| Data access | 3 in-memory singleton repositories |
| Model | 3 `Serializable` POJOs |

### 5.2 Key architectural decisions and patterns

- **Struts 2 action-per-method pattern**: one action class per functional area, with `method=` in `struts.xml` choosing the handler method. Action properties act as both the form bean and the view model (ValueStack).
- **Post/Redirect/Get**: mutating actions return `type="redirect"` results to avoid double-submit.
- **JSP behind `WEB-INF`**: views cannot be requested directly; only actions render them.
- **Singleton repository pattern** with `synchronized getInstance()` and thread-safe collections replaces a database - convenient for demos, not durable.
- **No service layer / no DI**: actions instantiate repositories through `getInstance()`, tightly coupling controller and data access.
- **Liberty deployment**: `server.xml` generated by the IBM Migration Application Bundler; WAR deployed via `liberty-maven-plugin`; container files (`Dockerfile`, `Containerfile`, `docker-compose.yml`) and run scripts provided.

### 5.3 Entry points and request handling

1. `GET /` -> `index.jsp` (welcome file) -> `response.sendRedirect("dashboard")`.
2. Every request passes `StrutsPrepareAndExecuteFilter` mapped to `/*`; URLs without extension are resolved as Struts action names (default `.action`/extensionless).
3. `ActionMapper` resolves the action in `struts.xml`; the `struts-default` interceptor stack runs (params, validation, workflow etc.), parameters are bound to action setters via OGNL.
4. The configured method executes and returns a result code that is mapped to a JSP or a redirect.

### 5.4 View resolution

- Result type defaults to `dispatcher`; the `success`/`error` names map to explicit JSP paths in `struts.xml`.
- `redirect` results use bare action names (e.g. `prescription-list`).
- `struts.convention.result.path=/WEB-INF/content/` is set and the Convention plugin is on the classpath, but all actions are explicitly configured, so convention scanning is effectively unused.
- `struts.ui.theme=simple` - tags render bare HTML; layout and CSS are duplicated in each JSP (no tiles/sitemesh template).
- `struts.devMode=true` is enabled (should be disabled for production).

### 5.5 Form beans and validation mechanisms

There are no `ActionForm`-style classes. Struts 2 binds request parameters directly to action fields (`PrescriptionAction`: `patientName`, `patientId`, `doctorName`, `medicineId`, `quantity`, `dosage`, `notes`; `OrderAction`: `orderId`, `prescriptionId`, `paymentMethod`, `pharmacistNotes`; `MedicineAction`: `medicineId`, `searchQuery`). There are no `*-validation.xml` files, no `validate()` overrides and no `@Validations` annotations; validation is done imperatively inside action methods (section 4.1).

### 5.6 Configuration approach

| File | Purpose |
|---|---|
| `src/main/webapp/WEB-INF/web.xml` | Servlet 3.1; Struts filter on `/*`; 30-min session timeout; welcome file `index.jsp` |
| `src/main/resources/struts.xml` | Constants, single package `pharmacy`, 15 action mappings |
| `src/main/liberty/config/server.xml` | Liberty features and HTTP endpoint (`host="*"`) |
| `pom.xml` | Struts 2.5.30, ASM 9.7, Javassist, Servlet 3.1 / JSP 2.3 (provided), JSTL, liberty-maven-plugin |

### 5.7 Struts action mapping catalogue

| Action name | Class # method | success | error |
|---|---|---|---|
| `dashboard` | `DashboardAction#execute` | `dashboard.jsp` | - |
| `prescription-list` | `PrescriptionAction#list` | `prescription-list.jsp` | - |
| `prescription-view` | `PrescriptionAction#view` | `prescription-view.jsp` (missing) | `prescription-list.jsp` |
| `prescription-create` | `PrescriptionAction#create` | `prescription-create.jsp` | - |
| `prescription-save` | `PrescriptionAction#save` | redirect `prescription-list` | `prescription-create.jsp` |
| `prescription-validate` | `PrescriptionAction#validatePrescription` | redirect `prescription-list` | redirect `prescription-list` |
| `order-list` | `OrderAction#list` | `order-list.jsp` | - |
| `order-view` | `OrderAction#view` | `order-view.jsp` | `order-list.jsp` |
| `order-createFromPrescription` | `OrderAction#createFromPrescription` | redirect `order-list` | redirect `prescription-list` |
| `order-processPayment` | `OrderAction#processPayment` | redirect `order-list` | `order-view.jsp` |
| `order-collect` | `OrderAction#collect` | redirect `order-list` | redirect `order-list` |
| `medicine-list` | `MedicineAction#list` | `medicine-list.jsp` | - |
| `medicine-view` | `MedicineAction#view` | `medicine-view.jsp` (missing) | `medicine-list.jsp` |
| `medicine-search` | `MedicineAction#search` | `medicine-list.jsp` | - |

### 5.8 Observed defects relevant to modernization

- `prescription-view.jsp` and `medicine-view.jsp` are referenced in `struts.xml` and linked from the UI but do not exist in `src/main/webapp/WEB-INF/content/` (a request results in an error).
- `order-view` error results to `order-list.jsp` and `prescription-list.jsp`/`order-list.jsp` error paths are dispatcher results from an action that did not populate the list (lists would be null/empty).
- `medicine-search` is submitted via GET and rendered directly; search text is echoed using Struts tags (output encoding behaviour should be confirmed).

---

## 6. Component Details

### 6.1 Controller components

| Class | Methods | Responsibility |
|---|---|---|
| `DashboardAction` | `execute` | Loads pending prescriptions/orders via `findByStatus("PENDING")` and totals via `findAll().size()` |
| `PrescriptionAction` | `list`, `view`, `create`, `save`, `validatePrescription` | Prescription CRUD subset and validation workflow; `create` preloads medicines for the drop-down |
| `OrderAction` | `list`, `view`, `createFromPrescription`, `processPayment`, `collect` | Order lifecycle, price calculation, stock check, payment and cross-entity updates |
| `MedicineAction` | `list`, `view`, `search` | Catalogue browsing and name search |

All extend `com.opensymphony.xwork2.ActionSupport` (gives `SUCCESS`/`ERROR`, action messages and errors, i18n). Actions are instantiated per request by Struts, so instance fields are not shared between users; the repositories they reference are shared singletons.

### 6.2 Views

| JSP | Purpose / key tags |
|---|---|
| `index.jsp` | Scriptlet redirect to `dashboard` |
| `dashboard.jsp` | Counters, tables of pending prescriptions/orders using `<s:iterator>`, `<s:if>`, `<s:url>`, `<s:param>` |
| `prescription-list.jsp` | Table with conditional Validate / Create Order buttons; `<s:date>` formatting |
| `prescription-create.jsp` | `<s:form action="prescription-save">`, `<s:textfield>`, `<s:select list="medicines" listKey="id">`, `<s:textarea>`, `<s:submit>` |
| `order-list.jsp` | Table with conditional Process Payment / Mark Collected actions |
| `order-view.jsp` | Detail display (`order.*` OGNL) and payment form with `<s:hidden>` and `<s:select list="{'CASH','CREDIT_CARD','INSURANCE'}">` |
| `medicine-list.jsp` | GET search form; stock-level style via `<s:if test='stockQuantity < 50'>` |

Each page contains its own navigation bar (Dashboard, Prescriptions, Orders, Medicines) and inline CSS.

### 6.3 Data access components

| Repository | Backing store | Seed data | Notable methods |
|---|---|---|---|
| `MedicineRepository` | `ConcurrentHashMap<String, Medicine>` | 8 medicines (MED001-MED008) | `findAll`, `findById`, `searchByName`, `updateStock` (decrements only if sufficient stock) |
| `PrescriptionRepository` | `ConcurrentHashMap` + `AtomicInteger(1000)` | RX001 PENDING, RX002 VALIDATED, RX003 FULFILLED | `generateId`, `findByStatus`, `findByPatientId`, `updatePrescription` |
| `OrderRepository` | `ConcurrentHashMap` + `AtomicInteger(5000)` | none | `generateId`, `findByStatus`, `findByPatientId`, `findByPrescriptionId`, `updateOrder` |

Data access characteristics: lazy singleton with `synchronized getInstance()`, stream-based filtering, objects returned by reference (mutations in actions affect the stored instance immediately), all data lost on restart, no transactions.

### 6.4 Business logic integration

Business logic lives directly in action methods; actions call repositories synchronously. Cross-entity orchestration (order + prescription + medicine) happens in `OrderAction.processPayment` without transaction boundaries - a failure part-way leaves inconsistent state.

---

## 7. Data Model

```mermaid
erDiagram
    MEDICINE ||--o{ PRESCRIPTION : "prescribed in"
    PRESCRIPTION ||--o{ ORDER : "fulfilled by"
    MEDICINE ||--o{ ORDER : "sold in"
    MEDICINE {
        string id PK
        string name
        string description
        decimal price
        int stockQuantity
        string manufacturer
    }
    PRESCRIPTION {
        string id PK
        string patientName
        string patientId
        string doctorName
        string medicineId FK
        string medicineName
        int quantity
        string dosage
        date prescriptionDate
        date expiryDate
        string status
        string notes
    }
    ORDER {
        string id PK
        string prescriptionId FK
        string patientName
        string patientId
        string medicineId FK
        string medicineName
        int quantity
        decimal totalAmount
        date orderDate
        string status
        string paymentMethod
        string pharmacistNotes
    }
```

Notes:

- There is no `Patient` or `Doctor` entity; patient and doctor details are free-text strings repeated on `Prescription` and (patient) on `Order`.
- Relationships are by string ID only; no referential integrity enforcement.
- A prescription holds a single medicine line; there are no multi-item prescriptions or orders.
- Money is represented as `BigDecimal`; dates as `java.util.Date`.

---

## 8. Integration Points

| Integration | Status |
|---|---|
| Database / JPA / JDBC | None used (Liberty `jdbc-4.1` feature enabled but no datasource configured) |
| External REST/SOAP services | None |
| Messaging | None |
| Payment gateway | Mock only (`processPayment` simply sets status and method) |
| Insurance / doctor / patient systems | None; `INSURANCE` is only a label |
| Authentication / SSO | None |
| Monitoring | Liberty `mpMetrics-1.1` feature enabled in `server.xml` |
| Deployment | Maven `liberty-maven-plugin`, `Dockerfile`/`Containerfile`, `docker-compose.yml`, `run-liberty.sh/.bat`, `Makefile` |

Internal integration seams (the places where a modernization would cut):

1. Action classes <-> repository singletons (replace with service layer + persistence).
2. Action properties <-> JSP via OGNL ValueStack (replace with JSON DTOs and REST endpoints).
3. `struts.xml` result mapping (replace with client-side routing and HTTP status codes).
4. Flash-style messages via `ActionSupport` (replace with API error payloads).
